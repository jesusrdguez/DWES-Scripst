<?php 

echo "<h1>¡Compra realizada con éxito!</h1>";

echo "<a href='main.php'>Página principal</a>";

?>